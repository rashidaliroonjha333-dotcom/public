const jobs = [
 {id:1,title:"Frontend Developer",company:"PixelCraft Studio",category:"Technology",location:"Karachi / Remote",type:"Full-time",salary: "PKR 90k–140k",min:90000,max:140000,initial:"P",date:6},
 {id:2,title:"UI/UX Designer",company:"Northstar Digital",category:"Design",location:"Remote",type:"Contract",salary:"PKR 70k–110k",min:70000,max:110000,initial:"N",date:5},
 {id:3,title:"Digital Marketing Associate",company:"BrightWave Media",category:"Marketing",location:"Lahore",type:"Full-time",salary:"PKR 55k–85k",min:55000,max:85000,initial:"B",date:4},
 {id:4,title:"Junior Data Analyst",company:"InsightLoop",category:"Technology",location:"Islamabad",type:"Full-time",salary:"PKR 65k–100k",min:65000,max:100000,initial:"I",date:3},
 {id:5,title:"Finance Assistant",company:"Cedar & Co.",category:"Finance",location:"Karachi",type:"Part-time",salary:"PKR 45k–65k",min:45000,max:65000,initial:"C",date:2},
 {id:6,title:"Online Tutor",company:"LearnBridge",category:"Education",location:"Remote",type:"Part-time",salary:"PKR 40k–75k",min:40000,max:75000,initial:"L",date:1}
];
const $ = (selector) => document.querySelector(selector);
const grid = $("#jobGrid"), empty = $("#emptyState");
let activeJob = null;
let saved = JSON.parse(localStorage.getItem("jobfinder-saved") || "[]");

function getFilteredJobs(){
 const keyword = ($("#keyword").value + " " + $("#inlineSearch").value).trim().toLowerCase();
 const location = $("#location").value.trim().toLowerCase();
 const category = $("#category").value;
 return jobs.filter(job => {
  const matchesText = !keyword || `${job.title} ${job.company} ${job.category} ${job.location}`.toLowerCase().includes(keyword);
  const matchesLocation = !location || job.location.toLowerCase().includes(location);
  return matchesText && matchesLocation && (!category || job.category === category);
 }).sort((a,b) => {
  const sort = $("#sortBy").value;
  if(sort === "salary-high") return b.max-a.max;
  if(sort === "salary-low") return a.min-b.min;
  return b.date-a.date;
 });
}
function renderJobs(){
 const filtered = getFilteredJobs();
 $("#resultCount").textContent = `${filtered.length} ${filtered.length === 1 ? "job" : "jobs"} found`;
 grid.innerHTML = filtered.map(job => `
  <article class="job-card">
   <div class="job-top"><div class="company-mark" aria-hidden="true">${job.initial}</div>
   <button class="save-btn ${saved.includes(job.id)?"saved":""}" data-save="${job.id}" aria-label="${saved.includes(job.id)?"Remove saved":"Save"} ${job.title}" aria-pressed="${saved.includes(job.id)}">${saved.includes(job.id)?"★":"☆"}</button></div>
   <h3>${job.title}</h3><p class="company">${job.company}</p>
   <div class="job-meta"><span class="tag">${job.location}</span><span class="tag blue">${job.type}</span><span class="tag">${job.category}</span></div>
   <div class="job-bottom"><span class="salary">${job.salary}</span><button class="apply-btn" data-apply="${job.id}">View & apply →</button></div>
  </article>`).join("");
 empty.hidden = filtered.length > 0;
 grid.hidden = filtered.length === 0;
}
function renderSaved(){
 const list = jobs.filter(job => saved.includes(job.id));
 $("#savedList").innerHTML = list.length ? list.map(job => `<div class="saved-item"><span><b>${job.title}</b> · ${job.company}</span><button data-remove="${job.id}" aria-label="Remove ${job.title} from saved jobs">Remove</button></div>`).join("") : '<p class="muted">You haven’t saved any jobs yet. Tap ☆ on a listing to save it.</p>';
 localStorage.setItem("jobfinder-saved",JSON.stringify(saved));
}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2400);}
$("#searchForm").addEventListener("submit",e=>{e.preventDefault();renderJobs();$("#jobs").scrollIntoView({behavior:"smooth"});});
$("#inlineSearch").addEventListener("input",renderJobs);
$("#sortBy").addEventListener("change",renderJobs);
$("#clearFilters").addEventListener("click",()=>{$("#keyword").value="";$("#location").value="";$("#category").value="";$("#inlineSearch").value="";renderJobs();});
document.querySelectorAll(".quick-search").forEach(btn=>btn.addEventListener("click",()=>{$("#keyword").value=btn.dataset.keyword;renderJobs();$("#jobs").scrollIntoView({behavior:"smooth"});}));
grid.addEventListener("click",e=>{
 const saveBtn=e.target.closest("[data-save]"), applyBtn=e.target.closest("[data-apply]");
 if(saveBtn){const id=Number(saveBtn.dataset.save);saved=saved.includes(id)?saved.filter(x=>x!==id):[...saved,id];renderJobs();renderSaved();toast(saved.includes(id)?"Job saved to your list":"Job removed from saved list");}
 if(applyBtn){activeJob=jobs.find(j=>j.id===Number(applyBtn.dataset.apply));$("#modalTitle").textContent=activeJob.title;$("#modalCompany").textContent=`${activeJob.company} · ${activeJob.location}`;$("#applyDialog").showModal();}
});
$("#savedList").addEventListener("click",e=>{const btn=e.target.closest("[data-remove]");if(!btn)return;saved=saved.filter(id=>id!==Number(btn.dataset.remove));renderSaved();renderJobs();toast("Saved job removed");});
$("#applyForm").addEventListener("submit",e=>{e.preventDefault();if(!e.currentTarget.reportValidity())return;const form=new FormData(e.currentTarget);const applications=JSON.parse(localStorage.getItem("jobfinder-applications")||"[]");applications.push({jobId:activeJob.id,jobTitle:activeJob.title,name:form.get("name"),email:form.get("email"),message:form.get("message"),submittedAt:new Date().toISOString()});localStorage.setItem("jobfinder-applications",JSON.stringify(applications));$("#applyDialog").close();e.currentTarget.reset();toast("Your demo application has been saved on this device");});
$("#menuToggle").addEventListener("click",()=>{const open=$("#mainNav").classList.toggle("open");$("#menuToggle").setAttribute("aria-expanded",String(open));});
$("#mainNav").addEventListener("click",e=>{if(e.target.closest("a")){$("#mainNav").classList.remove("open");$("#menuToggle").setAttribute("aria-expanded","false");}});
$("#loginBtn").addEventListener("click",()=>toast("Login is a demo feature in this frontend"));
$("#registerBtn").addEventListener("click",()=>toast("Registration is a demo feature in this frontend"));
$("#year").textContent=new Date().getFullYear();
renderJobs();renderSaved();
