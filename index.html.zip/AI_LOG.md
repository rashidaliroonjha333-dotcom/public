# AI Engineering Log

## Tools
- ChatGPT: project planning, feature breakdown, starter implementation, and documentation.
- Human review: verify requirements, test interactions, inspect generated code, and adapt content before deployment.

## Prompt / design log
1. “Create a responsive job-finder frontend using only HTML, CSS, and vanilla JavaScript.”
   - Outcome: semantic page structure, responsive styling, and sample listings.
2. “Add keyword, location, and category filtering plus sorting.”
   - Outcome: client-side filtering and salary/date sorting.
3. “Add saved jobs and persist them in localStorage.”
   - Outcome: save/remove actions and a saved-jobs section.
4. “Add an application modal with accessible labels and basic validation.”
   - Outcome: native dialog and local demo application storage.
5. “Review the frontend for mobile navigation, empty states, keyboard support, and reduced motion.”
   - Outcome: responsive menu, empty state, status messages, and reduced-motion CSS.

## Human-in-the-loop review checklist
- [ ] Test search with matching and non-matching keywords.
- [ ] Test category and location filters together.
- [ ] Test each sorting option.
- [ ] Save and remove jobs, then refresh to confirm persistence.
- [ ] Submit invalid and valid application form values.
- [ ] Test dialog close using Escape and the close button.
- [ ] Test mobile layout at 360px, tablet, and desktop widths.
- [ ] Check browser console and keyboard tab order.
- [ ] Replace fictional listings with verified opportunities before public use.

## Limitations
This is a frontend-only demo. Applications are stored locally and are not sent to companies. Login and registration controls are explanatory demo actions.
