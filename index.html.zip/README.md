# JobFinder

A responsive job discovery frontend built with vanilla HTML5, CSS3, and JavaScript (ES6+).

## Run locally
1. Download and extract the project.
2. Open `index.html` in a modern browser. For best results, use VS Code Live Server.
3. No package installation or build step is required.

## Features
- Search by keyword, location, and category
- Sort by newest and salary
- Save jobs with browser localStorage
- Application-interest dialog with form validation
- Responsive mobile navigation and layout
- Custom JobFinder SVG brand mark

## Project structure
```text
jobfinder_project/
├── index.html
├── css/style.css
├── js/app.js
├── assets/logo.svg
├── PRD.md
├── AI_LOG.md
└── README.md
```

## Important demo note
Listings are fictional sample data. Login, registration, and applications are frontend demonstrations only. No data is sent to an employer.

## Deployment
### GitHub Pages
1. Create a public GitHub repository.
2. Upload all project files while preserving folders.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
5. Wait for the Pages URL to appear and test it in a private browser window.

### Netlify
Drag the extracted project folder into Netlify Drop, or connect the GitHub repository.

## Submission links
- Live Demo URL: _Add your deployed URL here_
- Repository URL: _Add your public GitHub repository URL here_
